
<style>
	.img-not-found {
		width: 40%;
	}
	.div-not-found {
		text-align: center;
	}
</style>
<div class="div-not-found">
	
	<img src="<?php echo(base_url('images/not-found-page2.jpg')) ?>" alt="" class="img-not-found">
	<h3>Maaf, Halaman tidak ditemukan</h3>
	<a href="<?php echo(site_url()) ?>">Kembali ke Beranda</a>
</div>